<template>
	<div class="container mt-4">
		<div class="row">
			<div class="col">
				<div class="card" style="min-height: 70vh">
					<h4 class="p-5">Dashboar Admin Kamus Web Ku</h4>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>