<template>
	<div>
		<div class="header header-transparent dark-text">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12">
						<nav id="navigation" class="navigation navigation-landscape">
							<div class="nav-header">
								<a class="nav-brand" href="#">
									<img src="assets/img/logo-kbbi.png" class="logo" alt="" />
								</a>
								<div class="nav-toggle"></div>
							</div>
							<div class="nav-menus-wrapper">
								<ul class="nav-menu">
									<li class="active">
										<a href="index.php"
											>Home<span class="submenu-indicator"></span
										></a>
									</li>
									<li>
										<a href="#">KBBI<span class="submenu-indicator"></span></a>
										<ul class="nav-dropdown nav-submenu">
											<li><a href="kbbi.php">KBBI</a></li>
											<li><a href="kbbi-detail.php">KBBI Detail</a></li>
										</ul>
									</li>
									<li>
										<a href="#">Pages<span class="submenu-indicator"></span></a>
										<ul class="nav-dropdown nav-submenu">
											<li><a href="about.php">About Us</a></li>
											<li><a href="disclaimer.php">Disclaimer</a></li>
											<li><a href="privacy.php">Privacy Policy</a></li>
											<li><a href="contact.php">Contact Us</a></li>
										</ul>
									</li>
								</ul>
							</div>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<!-- End Navigation -->
		<div class="clearfix"></div>
		<!-- ================== TOP Header End ============================= -->
	</div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>