<template>
	<div class="gloss">
		<Gloss></Gloss>
	</div>
</template>

<script>
import Gloss from "../components/gloss/mainGloss.vue";
export default {
	components: {
		Gloss,
	},
};
</script>

<style lang="scss" scoped>
.gloss {
	background-color: #eef1f8;
}
</style>