<template>
	<div class="in-eng">
		<h3 class="mt-5">Terjemahan Bahasa Indonesia ke Inggris</h3>
		<Inmain></Inmain>
	</div>
</template>

<script>
import Inmain from "../components/translate/Inmain.vue";
export default {
	components: {
		Inmain,
	},
};
</script>

<style lang="scss" scoped>
</style>