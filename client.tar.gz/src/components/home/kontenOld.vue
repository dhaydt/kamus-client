<template>
	<div class="konten100 mt-5 pt-5">
		<b-container>
			<b-row>
				<b-col>
					<div class="header mb-2">
						<h2>
							KamusKBBI Kamus Bahasa Indonesia
							<span class="title">Terlengkap</span>
						</h2>
						<p>
							Kami memberikan informasi yang meliputi kamus kbbi, kamus
							translate indonesia inggris,
						</p>
					</div>
				</b-col>
			</b-row>
			<b-row class="justify-content-center">
				<b-col class="pharagrap mt-4" lg="9">
					<p>
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget
						felis eu nisl finibus consequat. Donec sodales justo nec tempor
						porttitor. Aliquam molestie, urna nec ultrices sodales, mi ligula
						bibendum arcu, accumsan condimentum enim ligula ac nibh. Sed viverra
						commodo odio nec elementum. Curabitur et erat in leo mollis sodales
						quis placerat velit. Fusce tempus, sem id laoreet efficitur, velit
						nunc luctus nisl, nec mattis lacus magna in magna. Sed vel urna
						velit. Quisque lacinia quam vulputate dolor placerat, eget facilisis
						elit cursus. Duis mattis finibus interdum. Nam efficitur condimentum
						eros in pretium. Vivamus interdum eros tincidunt nisi facilisis
						molestie. Mauris sed magna maximus, mattis nunc id, tempus nunc.
					</p>

					<p>
						Quisque auctor, arcu vel pellentesque tempus, mauris sem vehicula
						dui, vel molestie neque metus efficitur neque. Quisque lectus arcu,
						malesuada ut dictum vel, commodo et risus. Lorem ipsum dolor sit
						amet, consectetur adipiscing elit. Donec id fermentum nisi, vitae
						placerat velit. Maecenas nec turpis eu ipsum mattis lacinia
						ultricies sed purus. Suspendisse eget mi sit amet metus sagittis
						mattis. Nullam lacinia eros purus, malesuada varius arcu ullamcorper
						sit amet. Pellentesque non est euismod, aliquam nisl a, cursus
						lacus. Ut consectetur ligula non velit vehicula, at elementum tortor
						pellentesque. Ut aliquam semper tortor in sagittis. Praesent
						finibus, urna et euismod maximus, turpis nulla pellentesque lacus,
						et finibus mauris lectus a sapien. Sed sagittis metus venenatis
						lobortis euismod. Pellentesque rutrum hendrerit massa vitae rutrum.
						Phasellus non tincidunt magna.
					</p>

					<p>
						Mauris quis vestibulum mauris. Orci varius natoque penatibus et
						magnis dis parturient montes, nascetur ridiculus mus. Cras aliquam
						magna vel sapien ullamcorper pulvinar. Ut convallis felis lacus, eu
						tempor quam pulvinar sed. Sed euismod sapien ipsum, lobortis feugiat
						nisi volutpat a. Praesent interdum, mauris venenatis vehicula
						pellentesque, metus turpis lacinia est, ut vehicula ipsum lorem ac
						orci. Sed porta consectetur felis ac consequat. Quisque vitae nisl
						purus. Interdum et malesuada fames ac ante ipsum primis in faucibus.
						Duis cursus sapien sed enim volutpat mollis. In justo eros, laoreet
						a sodales eu, tempor eget leo. Nulla facilisi. Donec massa quam,
						tempus sit amet egestas et, posuere nec metus. Fusce ullamcorper
						molestie urna, id hendrerit tortor varius bibendum. Donec dignissim
						tempor libero, id laoreet quam convallis vitae.
					</p>

					<p>
						Vivamus ipsum arcu, tristique sit amet magna ac, finibus elementum
						erat. Etiam semper malesuada eros et molestie. Sed leo ex, facilisis
						in libero eget, posuere cursus lectus. Praesent eleifend urna eget
						neque vestibulum, in blandit est pulvinar. Aenean eget mi at sem
						mollis cursus. Aliquam tincidunt ut massa eget blandit. Mauris
						scelerisque nisl vitae velit placerat ultricies. Donec porttitor
						ante non leo dapibus condimentum. Mauris tristique vehicula sem, nec
						dictum metus porta et. Ut id euismod mi, eget faucibus libero.
						Curabitur dolor mi, congue feugiat ligula non, cursus gravida dui.
					</p>

					<p>
						Nullam hendrerit nunc id lectus pretium malesuada. Pellentesque
						eleifend felis vel velit rutrum, sed iaculis nisi hendrerit.
						Maecenas tempor facilisis urna quis facilisis. Mauris egestas libero
						at volutpat malesuada. Vivamus condimentum ultrices nunc, a
						facilisis velit suscipit sed. Sed sollicitudin, libero in congue
						imperdiet, est massa porta nibh, dignissim tempus odio eros sed
						erat. Integer elementum quam non elementum condimentum. In auctor
						lorem id malesuada gravida. Vivamus nec leo tempor, mollis metus
						eleifend, molestie diam. Donec pulvinar ex nisi, in consequat ante
						convallis a.
					</p>
				</b-col>
			</b-row>
		</b-container>
	</div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
.title {
	color: #0b85ec;
}

.header h2 {
	font-weight: 900;
	font-size: 30px;
}

.header p {
	font-size: 17px;
}

.pharagrap p {
	text-align: left;
	font-size: 14px;
}
</style>