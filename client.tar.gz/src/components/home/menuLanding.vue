<template>
	<!-- ============================ Landing Perkategori Section Start ==================================== -->
	<section class="min-sec">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-7 col-md-9">
					<div class="sec-heading">
						<h2>
							<span class="theme-cl-2">KamusKBBI.id</span> 5 kamus dalam 1
							website
						</h2>
						<p>Kamus KBBI, Eng-Ind, Ind-Eng, Istilah dan Arti Nama.</p>
					</div>
				</div>
			</div>
			<div class="row justify-content-center">
				<!-- Single Item -->
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="box-kamus">
						<div class="">
							<div class="mx-4">
								<h4>Kamus KBBI</h4>
								<p>
									There are many variations of passages of Lorem Ipsum
									available, but the majority have suffered alteration in some
									form, by injected humour, or randomised words which don't look
									even slightly believable. If you are going to use a passage of
									Lorem Ipsum, you need to be sure there isn't anything
									embarrassing hidden in the middle of text.
								</p>
							</div>
							<div class="mx-4 mt-5">
								<router-link to="/kbbi" class="btn btn-theme blue dark"
									>Detail</router-link
								>
							</div>
						</div>
					</div>
				</div>
				<!-- Single Item -->
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="box-kamus">
						<div class="">
							<div class="mx-4">
								<h4>Kamus Eng-Ind</h4>
								<p>
									Lorem Ipsum is simply dummy text of the printing and
									typesetting industry. Lorem Ipsum has been the industry's
									standard dummy text ever since the 1500s, when an unknown
									printer took a galley of type and scrambled it to make a type
									specimen book. It has survived not only five centuries, but
									also the leap into electronic typesetting, remaining
									essentially unchanged.
								</p>
							</div>
							<div class="mx-4 mt-5">
								<router-link to="/terjemahan" class="btn btn-theme blue dark"
									>Detail</router-link
								>
							</div>
						</div>
					</div>
				</div>
				<!-- Single Item -->
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="box-kamus">
						<div class="">
							<div class="mx-4">
								<h4>Kamus Ind-Eng</h4>
								<p>
									It is a long established fact that a reader will be distracted
									by the readable content of a page when looking at its layout.
									The point of using Lorem Ipsum is that it has a more-or-less
									normal distribution of letters, as opposed to using 'Content
									here, content here', making it look like readable English.
									Many desktop publishing packages and web page editors now use
									...
								</p>
							</div>
							<div class="mx-4 mt-5">
								<router-link to="/terjemahan" class="btn btn-theme blue dark"
									>Detail</router-link
								>
							</div>
						</div>
					</div>
				</div>
				<!-- Single Item -->
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="box-kamus">
						<div class="">
							<div class="mx-4">
								<h4>Kamus Istilah</h4>
								<p>
									There are many variations of passages of Lorem Ipsum
									available, but the majority have suffered alteration in some
									form, by injected humour, or randomised words which don't look
									even slightly believable. If you are going to use a passage of
									Lorem Ipsum, you need to be sure there isn't anything
									embarrassing hidden in the middle of text.
								</p>
							</div>
							<div class="mx-4 mt-5">
								<router-link to="/istilah" class="btn btn-theme blue dark"
									>Detail</router-link
								>
							</div>
						</div>
					</div>
				</div>
				<!-- Single Item -->
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="box-kamus">
						<div class="">
							<div class="mx-4">
								<img :src="iklanImage" alt="Slot Iklan" class="iklanBox" />
							</div>
						</div>
					</div>
				</div>
				<!-- Single Item -->
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="box-kamus">
						<div class="">
							<div class="mx-4">
								<h4>Kamus Artinama</h4>
								<p>
									It is a long established fact that a reader will be distracted
									by the readable content of a page when looking at its layout.
									The point of using Lorem Ipsum is that it has a more-or-less
									normal distribution of letters, as opposed to using 'Content
									here, content here', making it look like readable English.
									Many desktop publishing packages and web page editors now use
									...
								</p>
							</div>
							<div class="mx-4 mt-5">
								<router-link to="/artiama" class="btn btn-theme blue dark"
									>Detail</router-link
								>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- ============================ Landing PerKategori Section End ==================================== -->
</template>

<script>
import axios from "axios";
export default {
	data() {
		return {
			backendUrl: "",
			getAdUrl: "/getSecondAdv",
			urlImageData: "/getAdv/",
			urlImg: "/images/client/",
			iklanImage: "",
		};
	},
	created() {
		this.backendUrl = localStorage.mainUrl;
		this.getIdLast();
	},

	methods: {
		async getIdLast() {
			const resp = await axios.get(this.backendUrl + this.getAdUrl);
			const data = resp.data[1].images;
			const share = JSON.stringify(resp.data);
			localStorage.setItem("dataIklan", share);
			this.iklanImage = this.backendUrl + this.urlImg + data;
			// this.getImageData();
		},

		async getImageData() {
			const resp = await axios.get(
				this.backendUrl + this.urlImageData + this.idImg
			);
			const data = resp.data.data[0];
			console.log(data.title);
			this.iklanImage = this.backendUrl + this.urlImg + data.images;
		},
	},
};
</script>

<style lang="scss">
.iklanBox {
	max-width: 100%;
	height: auto;
}
</style>